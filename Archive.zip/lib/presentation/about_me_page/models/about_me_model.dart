// import '../../../core/app_export.dart';
// import 'describeathings_item_model.dart';

// class AboutMeModel {
//   Rx<List<DescribeathingsItemModel>> describeathingsItemList = Rx([
//     DescribeathingsItemModel(
//         question: "Describe a Things You really like to do".obs),
//     DescribeathingsItemModel(
//         question: "Describe a Things I love about my culture".obs),
//     DescribeathingsItemModel(
//         question: "Describe What kind of person You are.".obs),
//     DescribeathingsItemModel(
//         question:
//             "Describe your hobbies and activities that you like to participate in."
//                 .obs),
//     DescribeathingsItemModel(
//         question: "Describe About you Favorite Location".obs)
//   ]);
// }
