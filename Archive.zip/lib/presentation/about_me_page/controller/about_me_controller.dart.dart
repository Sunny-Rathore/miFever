import 'package:flutter/material.dart';
import 'package:mifever/core/app_export.dart';

class AboutMePageController extends GetxController {
  // AboutMePageController(this.proflieDetailsEditMyAlbumThreeModelObj);

  // Rx<AboutMeModel> proflieDetailsEditMyAlbumThreeModelObj;

  final descriptionController = TextEditingController();
}
