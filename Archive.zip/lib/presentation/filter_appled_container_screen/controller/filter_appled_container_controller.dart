import 'package:mifever/core/app_export.dart';import 'package:mifever/presentation/filter_appled_container_screen/models/filter_appled_container_model.dart';/// A controller class for the FilterAppledContainerScreen.
///
/// This class manages the state of the FilterAppledContainerScreen, including the
/// current filterAppledContainerModelObj
class FilterAppledContainerController extends GetxController {Rx<FilterAppledContainerModel> filterAppledContainerModelObj = FilterAppledContainerModel().obs;

 }
