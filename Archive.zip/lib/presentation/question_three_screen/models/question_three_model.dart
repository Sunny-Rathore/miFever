/// This class defines the variables used in the [question_three_one_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class QuestionThreeOneModel {}
