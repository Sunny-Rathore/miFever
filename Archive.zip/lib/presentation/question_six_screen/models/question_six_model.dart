import '../../../core/app_export.dart';/// This class defines the variables used in the [question_six_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class QuestionSixModel {Rx<List<String>> radioList = Rx(["lbl_casual_dating","msg_serious_relationship","msg_culture_learning","lbl_i_don_t_know"]);

 }
