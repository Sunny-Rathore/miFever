import '../../../core/app_export.dart';/// This class is used in the [eightyseven_item_widget] screen.
class EightysevenItemModel {EightysevenItemModel({this.id}) { id = id  ?? Rx(""); }

Rx<String>? id;

 }
