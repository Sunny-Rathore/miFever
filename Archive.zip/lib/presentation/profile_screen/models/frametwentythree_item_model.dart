import '../../../core/app_export.dart';

/// This class is used in the [frametwentythree_item_widget] screen.
class FrametwentythreeItemModel {
  Rx<String>? gamecontrollerThree = Rx("Gaming");

  Rx<bool>? isSelected = Rx(false);
}
