import 'package:mifever/core/app_export.dart';
import 'package:mifever/presentation/question_three_dialog/models/question_three_model.dart';

/// A controller class for the QuestionThreeDialog.
///
/// This class manages the state of the QuestionThreeDialog, including the
/// current questionThreeModelObj
class QuestionThreeController extends GetxController {
  Rx<QuestionThreeModel> questionThreeModelObj = QuestionThreeModel().obs;
}
