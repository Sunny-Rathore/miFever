import '../../../core/app_export.dart';/// This class is used in the [frame5_item_widget] screen.
class Frame5ItemModel {Rx<String>? man = Rx("Man");

Rx<bool>? isSelected = Rx(false);

 }
