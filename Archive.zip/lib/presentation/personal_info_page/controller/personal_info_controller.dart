import 'package:mifever/core/app_export.dart';
import 'package:mifever/presentation/personal_info_page/models/personal_info_model.dart';

class PersonalInfoController extends GetxController {
  PersonalInfoController(this.proflieDetailsPersonalInfoModelObj);

  Rx<PersonalInfoModel> proflieDetailsPersonalInfoModelObj;
}
