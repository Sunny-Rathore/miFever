import '../../../core/app_export.dart';

class AvailableLocationModel {
  Rx<String>? madridEupore = Rx("Madrid, Eupore");

  Rx<bool>? isSelected = Rx(false);
}
