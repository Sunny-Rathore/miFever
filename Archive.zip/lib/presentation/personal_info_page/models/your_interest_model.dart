import '../../../core/app_export.dart';

class YourInterestModel {
  Rx<String>? gamecontrollerThree = Rx("Gaming");

  Rx<bool>? isSelected = Rx(false);
}
