import 'package:mifever/core/app_export.dart';

class MyAlbumController extends GetxController {
  //MyAlbumController(this.proflieDetailsEditMyAlbumOneModelObj);

  //Rx<MyAlbumModel> proflieDetailsEditMyAlbumOneModelObj;
}
