import '../../../core/app_export.dart';/// This class is used in the [frametwentythree8_item_widget] screen.
class Frametwentythree8ItemModel {Rx<String>? gamecontrollerThree = Rx("Gaming");

Rx<bool>? isSelected = Rx(false);

 }
