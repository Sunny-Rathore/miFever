import '../../../core/app_export.dart';/// This class is used in the [widget2_item_widget] screen.
class Widget2ItemModel {Widget2ItemModel({this.id}) { id = id  ?? Rx(""); }

Rx<String>? id;

 }
