import '../../../core/app_export.dart';

class OtherDetailsItemWidgetModel {
  Rx<String>? playlist = Rx("Movie");

  Rx<bool>? isSelected = Rx(false);
}
