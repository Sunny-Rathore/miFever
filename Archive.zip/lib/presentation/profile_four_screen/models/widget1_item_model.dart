import '../../../core/app_export.dart';/// This class is used in the [widget1_item_widget] screen.
class Widget1ItemModel {Widget1ItemModel({this.id}) { id = id  ?? Rx(""); }

Rx<String>? id;

 }
