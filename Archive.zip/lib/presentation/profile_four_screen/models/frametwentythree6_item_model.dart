import '../../../core/app_export.dart';/// This class is used in the [frametwentythree6_item_widget] screen.
class Frametwentythree6ItemModel {Rx<String>? madridEupore = Rx("Madrid, Eupore");

Rx<bool>? isSelected = Rx(false);

 }
