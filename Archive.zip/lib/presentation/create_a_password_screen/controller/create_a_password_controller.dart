import 'package:mifever/core/app_export.dart';

class CreateAPasswordController extends GetxController {}
