import 'dart:developer' as consol;

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationService {
  static late FlutterLocalNotificationsPlugin _flutterLocalNotificationsPlugin;

  static Future<void> initialize() async {
    _flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    try {
      await _flutterLocalNotificationsPlugin.initialize(
        initializationSettings,
        onDidReceiveNotificationResponse:
            (NotificationResponse notificationResponse) async {
          onDidReceiveNotificationResponse(notificationResponse);
        },
        onDidReceiveBackgroundNotificationResponse: notificationTapBackground,
      );
    } catch (e) {
      consol.log('flutterLocalNotificationsPlugin.initialize error', error: e);
    }
  }

// initialize the plugin. app_icon needs to be a added as a drawable resource to the Android head project
  static const AndroidInitializationSettings initializationSettingsAndroid =
      AndroidInitializationSettings('@mipmap/ic_launcher');

  static const InitializationSettings initializationSettings =
      InitializationSettings(
    android: initializationSettingsAndroid,
  );

  static const AndroidNotificationDetails androidNotificationDetails =
      AndroidNotificationDetails(
    '0',
    'your channel name',
    channelDescription: 'your channel description',
    importance: Importance.max,
    priority: Priority.max,
    channelShowBadge: true,
    colorized: true,
    enableVibration: true,
    playSound: true,
    ticker: 'ticker',
  );

  static const NotificationDetails notificationDetails =
      NotificationDetails(android: androidNotificationDetails);

  static void onDidReceiveNotificationResponse(
      NotificationResponse notificationResponse) async {
    final String? payload = notificationResponse.payload;
    if (notificationResponse.payload != null) {
      debugPrint('notification payload: $payload');
    }
    // await Navigator.push(
    //   context,
    //   MaterialPageRoute<void>(builder: (context) => SecondScreen(payload)),
    // );
  }

  @pragma('vm:entry-point')
  static void notificationTapBackground(
      NotificationResponse notificationResponse) {
    final String? payload = notificationResponse.payload;
    if (notificationResponse.payload != null) {
      debugPrint('notification payload: $payload');
    }
  }

  static void showLocalNotification(RemoteMessage message) async {
    try {
      _flutterLocalNotificationsPlugin.show(
        0, // Notification ID
        message.notification?.title ?? '', // Title
        message.notification?.body ?? '', // Body
        notificationDetails,
        payload: 'New Payload',
      );
    } catch (e) {
      consol.log('Notification Error', error: e);
    }
  }
}
