import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_google_places_hoc081098/flutter_google_places_hoc081098.dart';
import 'package:flutter_google_places_hoc081098/google_maps_webservice_places.dart';
import 'package:geocoding/geocoding.dart' as get_cord_address;
import 'package:google_api_headers/google_api_headers.dart';
import 'package:location/location.dart' as location;
import 'package:location/location.dart';

import '../../theme/theme_helper.dart';

class GooglePlacesApiServices {
  static Future<PlacesDetailsResponse?> placeSelectAPI(
      BuildContext context, String startText) async {
    Prediction? p = await PlacesAutocomplete.show(
        textStyle: TextStyle(color: Colors.black),
        context: context,
        apiKey: "AIzaSyBMNUxVT1By8WKruZvhdhX0IUBaxCHWNGI",
        mode: Mode.overlay,
        onError: (response) {
          log("-->${response.status}");
        },
        language: 'fr',
        resultTextStyle: theme.textTheme.titleSmall,
        types: [],
        strictbounds: false,
        components: [],
        startText: startText,
        cursorColor: appTheme.redA200);
    return displayPrediction(p!);
  }

  static Future<PlacesDetailsResponse?> displayPrediction(Prediction? p) async {
    if (p != null) {
      GoogleMapsPlaces? places = GoogleMapsPlaces(
        apiKey: "AIzaSyBMNUxVT1By8WKruZvhdhX0IUBaxCHWNGI",
        apiHeaders: await const GoogleApiHeaders().getHeaders(),
      );
      PlacesDetailsResponse? detail =
          await places.getDetailsByPlaceId(p.placeId.toString());
      return detail;
    }
    return null;
  }

  final location.Location currentLocation = location.Location();

  getCurrentLocation(bool isDepartureSet) async {
    if (isDepartureSet) {
      try {
        LocationData location = await currentLocation.getLocation();
        List<get_cord_address.Placemark> placeMarks =
            await get_cord_address.placemarkFromCoordinates(
                location.latitude ?? 0.0, location.longitude ?? 0.0);

        final address = (placeMarks.first.subLocality!.isEmpty
                ? ''
                : "${placeMarks.first.subLocality}, ") +
            (placeMarks.first.street!.isEmpty
                ? ''
                : "${placeMarks.first.street}, ") +
            (placeMarks.first.name!.isEmpty
                ? ''
                : "${placeMarks.first.name}, ") +
            (placeMarks.first.subAdministrativeArea!.isEmpty
                ? ''
                : "${placeMarks.first.subAdministrativeArea}, ") +
            (placeMarks.first.administrativeArea!.isEmpty
                ? ''
                : "${placeMarks.first.administrativeArea}, ") +
            (placeMarks.first.country!.isEmpty
                ? ''
                : "${placeMarks.first.country}, ") +
            (placeMarks.first.postalCode!.isEmpty
                ? ''
                : "${placeMarks.first.postalCode}, ");
        // locationHint.value = address;
        // lat.value = location.latitude ?? 0.0;
        // lng.value = location.longitude ?? 0.0;
      } catch (e) {
        log('getCurrentLocation', error: e);
      }
    }
  }
}
