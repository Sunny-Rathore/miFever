// ignore_for_file: non_constant_identifier_names

import 'package:dio/dio.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:mifever/core/utils/progress_dialog_utils.dart';
import 'package:mifever/data/models/user/user_model.dart';
import 'package:mifever/data/sevices/firebase_services.dart';
import 'package:mifever/data/sevices/smtp_service.dart';

import '../models/subscriptions/subscription_model.dart';

class StripePaymentHandle {
  static String PUBLISHABLE_KEY =
      'pk_test_51FBglhJKDGfJmqFFVYCmWXYNO8jDhImWDOlMlE827r8CygQoj1r7vnGx8frYSi1oLNQp7VKx7W6b3L9ahnooqpMx00aaLwF8jf';
  static String STRIPE_SECRET = 'sk_test_ydpPmFCuJt0BUYCrp9X6AIAE005opzYN8x';
  static Map<String, dynamic>? paymentIntent;
  static SubscriptionModel? subscriptionModel;
  static Future<void> stripeMakePayment(SubscriptionModel model) async {
    subscriptionModel = model;
    try {
      ProgressDialogUtils.showProgressDialog();
      paymentIntent = await createPaymentIntent('100', 'INR');
      await Stripe.instance
          .initPaymentSheet(
              paymentSheetParameters: SetupPaymentSheetParameters(
                  allowsDelayedPaymentMethods: true,
                  customFlow: true,
                  billingDetails: BillingDetails(
                      name: 'Name',
                      email: 'YOUREMAIL@gmail.com',
                      phone: 'YOUR NUMBER',
                      address: Address(
                          city: 'YOUR CITY',
                          country: 'YOUR COUNTRY',
                          line1: 'YOUR ADDRESS 1',
                          line2: 'YOUR ADDRESS 2',
                          postalCode: 'YOUR PINCODE',
                          state: 'YOUR STATE')),
                  googlePay: const PaymentSheetGooglePay(
                      amount: '100',
                      // Currency and country code is according to India
                      testEnv: true,
                      currencyCode: "INR",
                      merchantCountryCode: "IN"),
                  paymentIntentClientSecret: paymentIntent!['client_secret'],
                  merchantDisplayName: 'Ikay'))
          .then((value) {});
      ProgressDialogUtils.hideProgressDialog();
      //STEP 3: Display Payment sheet
      displayPaymentSheet();
    } catch (e) {
      print(e.toString());
      Fluttertoast.showToast(msg: e.toString());
    }
  }

  static displayPaymentSheet() async {
    try {
      // 3.display the payment sheet.
      final result = await Stripe.instance.presentPaymentSheet();
      print(subscriptionModel!.userId);
      await FirebaseServices.addSubscription(subscriptionModel!);
      //confirmation email
      UserModel? user = await FirebaseServices.getCurrentUser();
      await sendMail(email: user!.email!, text: 'Your Plan Confirmed');
      print("result: $result");
      Fluttertoast.showToast(msg: 'Payment successfully completed');
    } catch (e) {
      print('Error:$e');
      if (e is StripeException) {
        Fluttertoast.showToast(msg: 'Payment Failed');
      } else {
        Fluttertoast.showToast(msg: 'Unforeseen error: $e');
      }
    }
  }

//create Payment
  static createPaymentIntent(String amount, String currency) async {
    var _dio = Dio();
    try {
      //Request body
      Map<String, dynamic> data = {
        'amount': calculateAmount(amount),
        'currency': currency,
      };
      //Make post request to Stripe
      var response = await _dio.post(
        'https://api.stripe.com/v1/payment_intents',
        options: Options(
          headers: {
            'Authorization': 'Bearer $STRIPE_SECRET',
            'Content-Type': 'application/x-www-form-urlencoded'
          },
        ),
        data: data,
      );
      return response.data;
    } catch (err) {
      throw Exception(err.toString());
    }
  }

//calculate Amount
  static calculateAmount(String amount) {
    final calculatedAmount = (int.parse(amount)) * 100;
    return calculatedAmount.toString();
  }
}
