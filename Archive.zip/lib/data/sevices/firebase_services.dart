// ignore_for_file: sdk_version_since

import 'dart:convert';
import 'dart:developer';
import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:mifever/core/app_export.dart';
import 'package:mifever/core/utils/progress_dialog_utils.dart';
import 'package:mifever/data/models/thermometer_model/thermometer_model.dart';
import 'package:mifever/data/models/user/user_model.dart';
import 'package:mifever/data/sevices/firebase_messageing_service.dart';
import 'package:mifever/data/sevices/media_services/media_services.dart';
import 'package:mifever/presentation/chat_screen/models/chat_model.dart';
import 'package:uuid/uuid.dart';

import '../../presentation/chat_screen/controller/chat_controller.dart';
import '../../widgets/custom_bottom_bar.dart';
import '../models/block/block_model.dart';
import '../models/like/like_model.dart';
import '../models/notification/notification.dart';
import '../models/subscriptions/subscription_model.dart';
import '../models/travel_plan/travel_plan_model.dart';

class FirebaseServices {
  static final FirebaseAuth _auth = FirebaseAuth.instance;
  static final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  static final FirebaseStorage _storage = FirebaseStorage.instance;
  static final GoogleSignIn googleSignIn = GoogleSignIn();

/*-----------Create User With Email and Password-----------*/
  static Future<bool> signUpWithEmail(
      {required String email, required String password}) async {
    return _auth
        .createUserWithEmailAndPassword(email: email, password: password)
        .then((userCredential) {
      if (userCredential.user != null) {
        Fluttertoast.showToast(msg: 'Success');
        return true;
      }
      return false;
    }).onError((error, stackTrace) {
      if (error is FirebaseAuthException) {
        Fluttertoast.showToast(
            msg: AuthExceptionHandler.handleException(error));
      } else {
        log('Error During SignUp with Email And Password', error: error);
      }
      return false;
    });
  }

/*-----------Sign In User With Email and Password-----------*/
  static Future<bool> signInWithEmail(
      {required String email, required String password}) async {
    ProgressDialogUtils.showProgressDialog();
    return _auth
        .signInWithEmailAndPassword(email: email, password: password)
        .then((userCredential) {
      if (userCredential.user != null) {
        Fluttertoast.showToast(msg: 'Success');
        PrefUtils.setId(userCredential.user!.uid);
        ProgressDialogUtils.hideProgressDialog();
        return true;
      }
      return false;
    }).onError((error, stackTrace) {
      ProgressDialogUtils.hideProgressDialog();
      if (error is FirebaseAuthException) {
        Fluttertoast.showToast(
            msg: AuthExceptionHandler.handleException(error));
      } else {
        log('Error During SignUp with Email And Password', error: error);
      }
      return false;
    });
  }

  static Future<User?> signInWithGoogle() async {
    try {
      final GoogleSignInAccount? googleSignInAccount =
          await googleSignIn.signIn();
      final GoogleSignInAuthentication googleSignInAuthentication =
          await googleSignInAccount!.authentication;

      final AuthCredential credential = GoogleAuthProvider.credential(
        accessToken: googleSignInAuthentication.accessToken,
        idToken: googleSignInAuthentication.idToken,
      );

      final UserCredential authResult =
          await _auth.signInWithCredential(credential);
      final User? user = authResult.user;
      PrefUtils.setId(authResult.user!.uid);
      if (authResult.additionalUserInfo!.isNewUser) {
        UserModel userModel = UserModel(
          token: await FirebaseMessagingService.generateToken(),
          email: authResult.user?.email ?? "",
          isProfileComplete: false,
        );
        await FirebaseServices.addUser(userModel);
        Get.offAllNamed(AppRoutes.questionOneScreen);
      } else {
        FirebaseServices.getCurrentUser().then((user) {
          if (user != null) {
            if (user.isProfileComplete ?? false) {
              PrefUtils.setId(authResult.user!.uid);
              PrefUtils.setUserName(user.name ?? '').then((value) {});
              Get.offAll(() => CustomBottomBar());
              //Get.offAllNamed(AppRoutes.homeScreen);
            } else {
              Get.offAllNamed(AppRoutes.questionOneScreen);
            }
          }
        });
      }
      return user;
    } catch (e) {
      log("Error during Google sign in:", error: e);
      return null;
    }
  }

/*-------Ad User--------*/
  static Future<bool> addUser(UserModel userModel) async {
    try {
      await _firestore
          .collection('users')
          .doc(_auth.currentUser?.uid)
          .set(userModel.toJson());
      ProgressDialogUtils.hideProgressDialog();
      return true;
    } catch (e) {
      log('Error during add user', error: e);
      return false;
    }
  }

/*-------Update User--------*/
  static Future<bool> updateUser(UserModel userModel) async {
    try {
      await _firestore
          .collection('users')
          .doc(_auth.currentUser?.uid)
          .update(userModel.toJson());
      ProgressDialogUtils.hideProgressDialog();
      return true;
    } catch (e) {
      log('Error during update user', error: e);
      return false;
    }
  }

/*-------Get User--------*/
  static Future<UserModel?> getCurrentUser() async {
    try {
      return await _firestore
          .collection('users')
          .doc(PrefUtils.getId())
          .get()
          .then((value) =>
              UserModel.fromJson(value.data() as Map<String, dynamic>));
    } catch (e) {
      log('Error during get user', error: e);
      return null;
    }
  }

  static Future<String> uploadFile(
      {required String filePath, required String contentType}) async {
    try {
      String base64Data = base64Encode(File(filePath).readAsBytesSync());
      String fileName = DateTime.now().millisecondsSinceEpoch.toString() +
          '_' +
          filePath.split('/').last;
      // Create a reference to the location you want to upload to in Firebase Storage
      Reference ref = _storage.ref().child('uploads/$fileName")');

      // Set metadata (content type)
      SettableMetadata metadata = SettableMetadata(contentType: contentType);
      // Upload file to Firebase Storage
      UploadTask uploadTask = ref.putData(base64.decode(base64Data), metadata);

      // Await the upload to get the task snapshot
      TaskSnapshot taskSnapshot = await uploadTask;

      // Get the download URL
      String downloadURL = await taskSnapshot.ref.getDownloadURL();

      return downloadURL;
    } catch (e) {
      log('Error uploading file:', error: e);
      return '';
    }
  }

/*-------add Way Album------*/
  static void addWayAlbum(String url) async {
    try {
      await _firestore.collection('users').doc(PrefUtils.getId()).update({
        'wayAlbum': FieldValue.arrayUnion([url])
      });
    } catch (e) {
      log('Error during add way album:', error: e);
    }
  }

/*-------add life Album------*/
  static void addLifeAlbum(String url) async {
    try {
      await _firestore.collection('users').doc(PrefUtils.getId()).update({
        'lifeAlbum': FieldValue.arrayUnion([url])
      });
    } catch (e) {
      log('Error during add life album:', error: e);
    }
  }

  /*-------edit Life Album------*/
  static void editLifeAlbum(List list) async {
    try {
      await _firestore
          .collection('users')
          .doc(PrefUtils.getId())
          .update({'lifeAlbum': list});
    } catch (e) {
      log('Error during edit life album:', error: e);
    }
  }

/*-------add Way Album------*/
  static void editWayAlbum(List list) async {
    try {
      await _firestore
          .collection('users')
          .doc(PrefUtils.getId())
          .update({'wayAlbum': list});
    } catch (e) {
      log('Error during edit life album:', error: e);
    }
  }

/*-----Get User---------*/
  static getUser() {
    return _firestore.collection('users').doc(PrefUtils.getId()).snapshots();
  }

/*-----Get All Users---------*/
  static getAllUsers() {
    return _firestore
        .collection('users')
        .where('id', isNotEqualTo: PrefUtils.getId())
        .where('isProfileComplete', isEqualTo: true)
        .snapshots();
  }

/*-----Get User By Id---------*/
  static getUserById(String id) {
    return _firestore.collection('users').doc(id).snapshots();
  }
/*-------Send Chat Message--------*/

  static Future<bool> sendMessage({
    required ChatModel chat,
  }) async {
    try {
      var chatRef = _firestore.collection('chats').doc(chat.roomId);
      chatRef.set({'timestamp': FieldValue.serverTimestamp()});
      chatRef.collection('messages').add(chat.toJson());
      return true;
    } catch (e) {
      log('Error during send message', error: e);
      return false;
    }
  }

/*---------Get Chats--------------*/
  static getChats(String receiverId) {
    try {
      return _firestore
          .collection('chats')
          .doc(createChatRoomId(receiverId))
          .collection('messages')
          .orderBy('timestamp', descending: false)
          .snapshots();
    } catch (e) {
      log('Error during get chats', error: e);
    }
  }

/*---------Delete Chats--------------*/
  static deleteChats(String receiverId) async {
    try {
      // Get a reference to the collection
      CollectionReference collectionReference = _firestore
          .collection('chats')
          .doc(createChatRoomId(receiverId))
          .collection('messages');
      // Get all documents from the collection
      QuerySnapshot querySnapshot = await collectionReference.get();
      // Delete each document in the collection
      querySnapshot.docs.forEach((document) async {
        await document.reference.delete();
      });
    } catch (e) {
      log('Error during delete chats', error: e);
    }
  }

/*---------Get Last Chats--------------*/
  static getLastChats(String receiverId) {
    try {
      return _firestore
          .collection('chats')
          .doc(createChatRoomId(receiverId))
          .collection('messages')
          .orderBy('timestamp', descending: true)
          .snapshots();
    } catch (e) {
      log('Error during get chats', error: e);
    }
  }

/*---------ad like ------*/
  static addLike({required String receiverId}) async {
    try {
      DocumentReference docRef = FirebaseFirestore.instance
          .collection('likes')
          .doc(createChatRoomId(receiverId));
      // Fetch the document snapshot
      DocumentSnapshot docSnapshot = await docRef.get();
      // Check if the document exists
      if (docSnapshot.exists) {
        ThermometerModel thermometerModel = ThermometerModel(
          roomId: FirebaseServices.createChatRoomId(receiverId),
          percentageValue: 100,
        );
        FirebaseServices.addThermometerValue(thermometerModel);
        LikeModel likeModel =
            LikeModel.fromJson(docSnapshot.data() as Map<String, dynamic>);
        Duration difference =
            DateTime.now().difference(DateTime.parse(likeModel.timestamp!));

        await _firestore
            .collection('likes')
            .doc(createChatRoomId(receiverId))
            .update({
          'updateTimestamp': Timestamp.now().toString(),
          'userIds': FieldValue.arrayUnion([PrefUtils.getId()]),
          'isMatched': true,
          'isSuperLiked': difference.inSeconds < 10
        });
        if (difference.inSeconds < 10) {
          //Show Super Like Screen
        }
      } else {
        LikeModel like = LikeModel(
          roomId: FirebaseServices.createChatRoomId(receiverId),
          userIds: [PrefUtils.getId()],
          notSeenUserIds: [PrefUtils.getId(), receiverId],
          timestamp: DateTime.now().toString(),
          updateTimestamp: DateTime.now().toString(),
          isMatched: false,
          isSuperLiked: false,
        );
        await _firestore
            .collection('likes')
            .doc(createChatRoomId(receiverId))
            .set(like.toJson());
      }
    } catch (e) {
      log('Error During add like', error: e);
    }
  }

/*---------fetchLikedUser------*/
  static getMatchUser() {
    return _firestore
        .collection('likes')
        .where('isMatched', isEqualTo: true)
        .where('userIds', arrayContains: PrefUtils.getId())
        .snapshots();
  }

/*-------- generate unique chat id for one to one user -----*/
  static String createChatRoomId(String receiverId) {
    List<String> userIds = [PrefUtils.getId(), receiverId];
    userIds.sort(); // Sort the user IDs to ensure consistency
    return userIds.join('_');
  }

/*------------Ad notification----------*/
  static Future<void> addNotification(NotificationModel notification) async {
    try {
      _firestore.collection('notifications').add(notification.toJson());
    } catch (e) {
      log('Error During Add Notification');
    }
  }

/*------------get my likes notification----------*/
  static getMyLikes() {
    return _firestore
        .collection('notifications')
        .where('notificationBy', isEqualTo: PrefUtils.getId())
        .snapshots();
  }

/*------------get LikedMe notification----------*/
  static getLikedMe() {
    return _firestore
        .collection('notifications')
        .where('notificationTo', isEqualTo: PrefUtils.getId())
        .snapshots();
  }

/*------Block user-------*/
  static addBlockUser(BlockModel model) async {
    await _firestore.collection('blockedUsers').add(model.toJson());
  }

/*------ get Block user-------*/
  static getBlockUser(String receiverId) {
    return _firestore
        .collection('blockedUsers')
        .where('blockBy', isEqualTo: PrefUtils.getId())
        .where('blockTo', isEqualTo: receiverId)
        .snapshots();
  }

/*------ get Block user-------*/
  static getBlockByUser(String receiverId) {
    return _firestore
        .collection('blockedUsers')
        .where('blockBy', isEqualTo: receiverId)
        .where('blockTo', isEqualTo: PrefUtils.getId())
        .snapshots();
  }

/*------ unBlock Block user-------*/
  static unBlockUser(String docId) async {
    await _firestore.collection('blockedUsers').doc(docId).delete();
  }

/*-----Media Chat------*/
  static Future<void> sendMediaChat(String receiverId) async {
    try {
      Media? media = await MediaServices.pickFilePathAndExtension();
      if (media != null) {
        String roomId = FirebaseServices.createChatRoomId(receiverId);
        String docId = const Uuid().v4();

        final _chat = ChatModel(
          roomId: roomId,
          isSeen: false,
          receiverId: receiverId,
          senderId: PrefUtils.getId(),
          message: '',
          timestamp: DateTime.now().toString(),
          type: MessageType.Media.name,
          url: '',
          fileName: media.name,
          fileExtension: media.fileExtension,
          linkCount: 0,
          userIdsOfUsersForStarredMessage: [],
          userIdsOfUsersForDeletedMessage: [],
        );
        var chatRef = _firestore.collection('chats').doc(roomId);
        chatRef.set({'timestamp': FieldValue.serverTimestamp()});
        chatRef.collection('messages').doc(docId).set(_chat.toJson());
        String url = await uploadFile(
            filePath: media.path, contentType: media.fileExtension);
        chatRef.collection('messages').doc(docId).update({'url': url});
      }
    } catch (e) {
      log('Error during sendMedia:', error: e);
    }
  }

  static Future<void> sendVideoChat(String receiverId) async {
    try {
      String filePath = await MediaServices.recordVideo();
      if (filePath.isNotEmpty) {
        String roomId = FirebaseServices.createChatRoomId(receiverId);
        String docId = const Uuid().v4();
        final _chat = ChatModel(
          roomId: roomId,
          isSeen: false,
          receiverId: receiverId,
          senderId: PrefUtils.getId(),
          timestamp: DateTime.now().toString(),
          type: MessageType.Video.name,
          url: '',
          fileExtension: '.mp4',
        );
        var chatRef = _firestore.collection('chats').doc(roomId);
        chatRef.set({'timestamp': FieldValue.serverTimestamp()});
        chatRef.collection('messages').doc(docId).set(_chat.toJson());
        String url = await uploadFile(filePath: filePath, contentType: '.mp4');
        chatRef.collection('messages').doc(docId).update({'url': url});
      }
    } catch (e) {
      log('Error during send video:', error: e);
    }
  }

/*------Add Themometer Value---------*/
  static addThermometerValue(ThermometerModel thermometerModel) async {
    try {
      await _firestore
          .collection('thermometer')
          .doc(thermometerModel.roomId)
          .set(thermometerModel.toJson());
    } catch (e) {
      log('Error during add Thermometer', error: e);
    }
  }

/*------Get Themometer Value---------*/
  static Future<int> getThermometerValue(String receiverId) async {
    try {
      return await _firestore
          .collection('thermometer')
          .doc(createChatRoomId(receiverId))
          .get()
          .then((value) {
        print('value');
        print(value.data());
        ThermometerModel thermometerModel =
            ThermometerModel.fromJson(value.data() as Map<String, dynamic>);
        return thermometerModel.percentageValue;
      });
    } catch (e) {
      log('Error during get Thermometer', error: e);
      return 0;
    }
  }
/*------Add Subscription---------*/

  static addSubscription(SubscriptionModel subscriptionModel) async {
    try {
      await _firestore
          .collection('subscriptions')
          .add(subscriptionModel.toJson());
    } catch (e) {
      log('Error during add Subscription', error: e);
    }
  }

  static Future<SubscriptionModel?> getSubscription() async {
    return _firestore
        .collection('subscriptions')
        .where('userId', isEqualTo: PrefUtils.getId())
        .where('expireTimestamp', isGreaterThan: DateTime.now().toString())
        .get()
        .then((value) {
      var data = value.docs;
      if (data.length > 0) {
        var mapData = data[0].data();
        return SubscriptionModel.fromJson(mapData);
      }
      return null;
    });
  }

  static addTravelPlan(TravelPlanModel travelPlanModel) async {
    try {
      await _firestore.collection('travel_plans').add(travelPlanModel.toJson());
    } catch (e) {
      log('Error during add travel PLans', error: e);
    }
  }

  static updateTravelPlan(
      {required TravelPlanModel travelPlanModel, required String docId}) async {
    try {
      await _firestore
          .collection('travel_plans')
          .doc(docId)
          .update(travelPlanModel.toJson());
    } catch (e) {
      log('Error during update travel PLans', error: e);
    }
  }

  static deleteTravelPlan({required String docId}) async {
    try {
      await _firestore.collection('travel_plans').doc(docId).delete();
    } catch (e) {
      log('Error during delete travel PLans', error: e);
    }
  }

  static getTravelPlan() {
    return _firestore
        .collection('travel_plans')
        .where('userId', isEqualTo: PrefUtils.getId())
        .snapshots();
  }

// Find Match Users
  static void listenToFieldChanges() {
    // Set up the query
    Query query = _firestore
        .collection('likes')
        .where('isMatched', isEqualTo: true)
        .where('notSeenUserIds', arrayContains: PrefUtils.getId())
        .limit(1);
    // Create a stream from the query
    Stream<QuerySnapshot> stream = query.snapshots();
    // Listen to changes in the stream
    stream.listen((QuerySnapshot snapshot) {
      // Handle changes here
      if (snapshot.docs.isNotEmpty) {
        String id = snapshot.docs[0].id
            .replaceAll(PrefUtils.getId(), '')
            .replaceAll("_", "");
        bool isSuperlike = snapshot.docs[0]['isSuperLiked'];
        if (isSuperlike) {
          print('object ::$isSuperlike');
          Get.toNamed(AppRoutes.matchScreenOneScreen, arguments: [id]);
        } else {
          Get.toNamed(AppRoutes.matchScreenTwoScreen, arguments: [id]);
        }
        _firestore.collection('likes').doc(createChatRoomId(id)).update({
          'notSeenUserIds': FieldValue.arrayRemove([PrefUtils.getId()]),
        });
        print("id==" + id.toString());
      } else {
        print('No matching documents found.');
      }
    });
  }

/*------get disliked user-----------*/
  static Future<List<NotificationModel>> allDisLikedUserByMe() async {
    try {
      print('try1212121');
      QuerySnapshot<Map<String, dynamic>> snapshot = await _firestore
          .collection('notifications')
          .where('type', isEqualTo: NotificationType.DisLike.name)
          .where('notificationBy', isEqualTo: PrefUtils.getId())
          .get();
      var data = snapshot.docs;
      List<NotificationModel> _dislikeNotification = <NotificationModel>[];
      _dislikeNotification.clear();
      _dislikeNotification =
          data.map((e) => NotificationModel.fromJson(e.data())).toList();
      return _dislikeNotification;
    } catch (e) {
      log('Error During  Get Dislike User', error: e);
      return <NotificationModel>[];
    }
  }

  static Future<void> handleLogOut() async {
    googleSignIn.signOut();
    _auth.signOut();
  }
}
