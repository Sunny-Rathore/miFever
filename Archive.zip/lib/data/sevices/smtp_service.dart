import 'dart:math';

import 'package:flutter/material.dart';
import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server/gmail.dart';

import '../../core/utils/progress_dialog_utils.dart';

Future<void> sendMail({required String email, required String text}) async {
  String username = 'rathoreankit582@gmail.com';
  String password = 'adfh fciu fyak hbue';

  final smtpServer = gmail(username, password);

  final message = Message()
    ..from = Address(username, 'Your Name')
    ..recipients.add(email)
    ..subject = 'Test Email'
    ..text = text;
  // 'Your otp for MiFever verification is'.tr + "$otp";

  try {
    ProgressDialogUtils.showProgressDialog();
    final sendReport = await send(message, smtpServer);
    ProgressDialogUtils.hideProgressDialog();
    debugPrint('Message sent: ${sendReport.toString()}');
  } catch (e) {
    print('Error occurred: $e');
  }
}

int generateRandomNumber() {
  Random random = Random();
  return 1000 + random.nextInt(9000);
}
